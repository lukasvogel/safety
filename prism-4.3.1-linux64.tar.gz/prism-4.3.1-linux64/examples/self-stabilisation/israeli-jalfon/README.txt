This case study is based on Israeli and Jalfon's self-stabilising algorithm [IJ90].

For more information, see: http://www.prismmodelchecker.org/casestudies/self-stabilisation.php

=====================================================================================

[IJ90]
A. Israeli and M. Jalfon
Token management schemes and random walks yeild self-stabilizating mutual exclusion
In Proc. ACM Symposium on Principles of Distributed Computing, pp. 119-131, 1990
